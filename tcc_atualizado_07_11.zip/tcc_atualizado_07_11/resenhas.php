<?php
	include 'listaJogos.php';
	$arrayJogos = listaJogos();
	$contador = 0;
	$outroContador = 0;
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
	position: relative;
	width: 24%;
	float: left;
}

.image {
	display: block;
	width: 80%;
	height: 100%;
	float: center;
}


.overlay {
	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	height: 100%;
	width: 100%;
	opacity: 0;
	transition: .5s ease;
	background-color: #008CBA;
	float: center;
}

.container:hover .overlay {
	opacity: 1;
}

.text {
	color: white;
	font-size: 20px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	text-align: center;
	font-family:cleon;
}
</style>

</head>



<body class="background">


	<div class="ui vertical masthead center aligned segment">


		<br>
		<br>
		<br>
		<?php foreach ($arrayJogos as $jogo):?>
			
				<div class="four wide column">

					<div class="container">
						<a href="detalhaJogo.php?cont=0&id=<?=$jogo['id'] ?>">
							<div class="sides">
								<div class="active side">

									<img src="fotos/<?=$jogo['foto']?>" alt="Avatar" class="image">
									<div class="overlay">
										<div class="text"><?=$jogo['titulo']?></div>
									</div>

								</div>
							</div>
						</a>
					</div>
				</div>
		
		<?php $contador++;
		if ($contador==4) {
			$contador=0;
			echo "<div class='ui hidden clearing divider'></div>";
		}
		endforeach;?>
	</div>
<br>
<br>
<br
