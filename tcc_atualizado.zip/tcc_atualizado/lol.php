<?php
include"cabecalho.php";
?>

<h1 class="jogos">League Of Legends</h1>
<img class="imagem" src="fotos/lol1.jpg">
<section id="jogos">
  <h1 class="text3">LoL (League of Legends) é um jogo online competitivo que mistura a velocidade e a intensidade de um RTS com elementos de RPG. Duas equipes de poderosos campeões, cada um com design e estilo único, lutam em diversos campos de batalha e modos de jogo. Com um elenco de campeões em constante expansão, atualizações frequentes e uma cena competitiva exuberante, LoL oferece diversão incessante para jogadores de todos os níveis de habilidade.
  O LoL conta com 118 personagens, cada um com seus próprios estilos, habilidades e histórias, cada um desses com suas particularidades, desde o modo de andar até em sua fala. Eles são divididos em 5 classes dentro do jogo. Assassino, Lutador, Mago, Suporte, Tanque e Francoatirador. Porém, os jogadores criaram outras classes para agilizar a escolha de um bom time dentro do jogo, que são eles ADC, Top, Mid, Suporte e Jungle.</h1>

  <section>
    <a class="ui label">
     <strong> ㅤAutor:</strong> ㅤ Leonardo Pinheiro 
   </a>

   <a class="ui label">
     <strong>ㅤ Nota do Autor:</strong>ㅤ10,0
   </a>
   <div class="ui labeled button" tabindex="0">
    <div class="ui red button">
      <i class="heart icon"></i> Like 
    </div>

  </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
  <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>