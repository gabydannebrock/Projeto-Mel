<?php
include"cabecalho.php";
?>
<h1 class="jogos_pb">PlayerUnknown’s Battlegrounds</h1>
<img class="imagem" src="fotos/pb2.jpg">
<section id="jogos">
  <h1 class="text3">Já assistiu ou leu "Jogos vorazes"? Então é meio caminho andado. "Battlegrounds" é um game de tiro online e multiplayer em que até 100 jogadores saltam de pára-quedas numa ilha enorme, de 64 km².
  Todos começam o jogo apenas com as roupas do corpo – às vezes nem isso, já que elas ocupam espaço no inventário – e devem explorar prédios e outras construções para encontrar armas, equipamentos de defesa e itens de cura. O objetivo é um só: se preparar para o pior e lutar até a morte contra os outros que estão na mesma situação que você. Afinal, vence o último a sobreviver.</h1>

  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Luiza Farias
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ10,0
    </a>
    <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
        <i class="heart icon"></i> Like
      </div>

    </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>
  
  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>