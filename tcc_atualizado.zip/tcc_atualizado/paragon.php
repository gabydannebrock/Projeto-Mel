<?php
include"cabecalho.php";
?>

<h1 class="jogos">Paragon</h1>
<img class="imagem" src="fotos/paragons2.jpg">
<section id="jogos">
  <h1 class="text3">Paragon é um MOBA jogado em terceira pessoa. Contando atualmente com apenas um modo de jogo, o mapa apresenta três rotas: esquerda, meio e direita. O jogador terá que defender uma delas ou se aventurar pela selva, onde poderá criar emboscadas para o adversário.
  O objetivo do game é destruir o núcleo que funciona como o coração do time. Para isso, ele e sua equipe deverão destruir tropas inimigas, lutar contra heróis adversários e destruir as torres para chegar ao núcleo, ao passo que evolui seu personagem, melhora suas habilidades e compra itens.  Uma das características de Paragon são seus gráficos. Embora o jogo esteja em acesso antecipado, é notável o poder de processamento gráfico da Unreal Engine 4. Apesar de ainda não estarem concluídos, os heróis e cenários já estão bem lapidados, com texturas, efeitos de partículas e iluminação dignas de um jogo AAA. Infelizmente, ainda não é possível conferir alguns personagens do game, como as tropas da selva, que atualmente são mostrados em modelos não-renderizados, com uma grande frase escrita abaixo: “Alpha Content”.</h1>

  <section>
    <a class="ui label">
     <strong> ㅤAutor:</strong> ㅤ Gabrielle Dannebrock
   </a>

   <a class="ui label">
     <strong>ㅤ Nota do Autor:</strong>ㅤ7,0
   </a>
   <div class="ui labeled button" tabindex="0">
    <div class="ui red button">
      <i class="heart icon"></i> Like
    </div>

  </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
  <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>