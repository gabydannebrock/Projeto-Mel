<?php
include"cabecalho.php";
?>

<h1 class="ui horizontal divider header" id="tamCadastro">Denunciar</h1>

<section class="margem">
  <br>

  <h1 class=" fiel text cadResenha1">Motivo da Denuncia</h1>
  <div class="two fields">
    <br>
    <form class="ui form">
      <textarea rows="4" id="mensagem" style="width: 41em"  name="mensagem"></textarea>
    </div>
  </fieldset>
  <br>
  

  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ 
  <div class="ui button " tabindex="0">Enviar Denuncia</div>
</div>
</div>



