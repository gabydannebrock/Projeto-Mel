<?php
include"cabecalho.php";
?>

<h1 class="jogos">Smite</h1>
<img class="imagem" src="fotos/smite2.jpg">
<section id="jogos">
  <h1 class="text3">Imagine deuses de todas as mitologias juntos num mesmo jogo lutando uns contra os outros. Imagine Loki e Thor no mesmo time lutamos juntos por um mesmo propósito. Ou, melhor ainda, imagine Zeus, Serqet, Baco, Kali, Ao Kang e Fenrir juntos num mesmo time lutando pela vitória. O que é isso? Isso é Smite, um jogo que une mitologias grega, romana, egípcia, maia, chinesa, nórdica, hindu e que conseguiu acabar com minha produtividade.
    É um gênero para jogos que misturam estratégia em tempo real e RPG. Nos jogos desse estilo, você controla uma unidade em batalha contra outros jogadores. As partidas acontecem num mesmo mapa e é disputado por dois times. O objetivo é destruir a base da equipe rival. Para isso, é preciso evoluir seu herói, melhorar seus equipamentos e derrubar as defesas do outro time, em ondas consecutivas de ataques que exigem raciocínio rápido e estratégias de equipe.
  Só que a grande diferença é que, nesse jogo, você joga vendo o personagem em terceira.</h1>
  
  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Gabrielle Dannebrock
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ8,5
    </a>

    <?php

    if(isset($_GET['cont'])){

      if($_GET['cont']==0 ) {


        echo'
        <a href="smite.php?cont=1">

        <div class="ui labeled button" tabindex="0">
        <div class="ui red button">
        <i class="thumbs up outline icon"></i> Like


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ';

      }else{
        echo '
        <a href="smite.php?cont=0">

        <div class="ui labeled button" tabindex="0">
        <div class="ui blue button">
        <i class="thumbs down outline icon"></i> Deslike

        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>

        ';
      }
    }else{
      $_GET['cont']=0;
    }

    ?>
    ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>
  
  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

  <?php
  include"rodape.php";
  ?>