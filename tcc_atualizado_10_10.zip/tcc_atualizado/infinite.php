<?php
include"cabecalho.php";
?>
<h1 class="jogos">Infinite Crisis</h1>
<img class="imagem" src="fotos/infinite2.jpg">
<section id="jogos">
  <h1 class="text3">Infinite Crisis é um MOBA baseado nos multiversos da DC Comics, onde os mesmos multiversos estão misteriosamente, e lentamente, se colidindo em algo chamado “sangria”. Devido a isso, a introdução de vários personagens e suas diferentes versões do multiverso dão o ponto de ignição ao jogo e sua trama.
  Inicialmente, o jogo apresenta um padrão, tendo uma preocupação em ensinar novos e até mesmos experientes jogadores através dos tutoriais explicando os conceitos básicos de um MOBA, que são aplicados de formas ligeiramente diferentes dos jogos do mesmo gênero neste jogo. O jogo também se preocupa em lhe dar uma base pós-tutorial, onde você libera alguns personagens após passar pelas as 5 etapas de tutorial existente para começar a jogar as partidas players vs. player, além de contar com a rotação semanal grátis de personagens. Entre os personagens liberados temos: Gaslight Batman, Lanterna Verde, Mulher Maravilha, Apocalipse e Arlequina.</h1>
  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Gabrielle Dannebrock
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ7,5
    </a>

    <?php

    if(isset($_GET['cont'])){

      if($_GET['cont']==0 ) {


        echo'
        <a href="infinite.php?cont=1">

        <div class="ui labeled button" tabindex="0">
        <div class="ui red button">
        <i class="thumbs up outline icon"></i> Like


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ';

      }else{
        echo '
        <a href="infinite.php?cont=0">

        <div class="ui labeled button" tabindex="0">
        <div class="ui blue button">
        <i class="thumbs down outline icon"></i> Deslike

        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>

        ';
      }
    }else{
      $_GET['cont']=0;
    }

    ?>
    ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>
  
  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

  <?php
  include"rodape.php";
  ?>