<?php
include"cabecalho.php";
?>
<h1 class="jogos">Heroes Of The Storm</h1>
<img class="imagem" src="fotos/heroes2.jpg">
<section id="jogos">
  <h1 class="text3">Lançado em 2015, o caçula dos melhores jogos MOBA foi lançado pela Blizzard. Ele surgiu tentando mudar um pouco o conceito fechado dos MOBAs, que sempre seguem uma orientação tradicional dos mapas e dos personagens. Em HotS existem 10 mapas diferentes para travar as batalhas, e cada mapa tem objetivos e mecânicas diferentes. Uma boa ideia da Blizzard foi colocar como heróis do jogo os personagens já consagrados, vindos de outras franquias da desenvolvedora. Em HotS é possível jogar com personagens de Diablo, Warcraft, StarCraft e Overwatch. Jogadores iniciantes conseguem aprender rapidamente as funcionalidades do jogo utilizando os tutoriais e os modos de teste para aprender as habilidades dos heróis.</h1>

  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Gabrielle Dannebrock
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ8,9
    </a>

    <?php

    if(isset($_GET['cont'])){

      if($_GET['cont']==0 ) {


        echo'
        <a href="heroes.php?cont=1">

        <div class="ui labeled button" tabindex="0">
        <div class="ui red button">
        <i class="thumbs up outline icon"></i> Like


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ';

      }else{
        echo '
        <a href="heroes.php?cont=0">

        <div class="ui labeled button" tabindex="0">
        <div class="ui blue button">
        <i class="thumbs down outline icon"></i> Deslike

        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>

        ';
      }
    }else{
      $_GET['cont']=0;
    }

    ?>

    ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>
  
  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

  <?php
  include"rodape.php";
  ?>