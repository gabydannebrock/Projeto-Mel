<?php
	
	function listaJogos(){
		$jogos = file_get_contents("json/jogo.json");
		$arrayJogos = json_decode($jogos,true);
		return $arrayJogos;
	}