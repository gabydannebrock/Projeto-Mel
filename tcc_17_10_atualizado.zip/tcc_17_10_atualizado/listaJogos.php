<?php
	
	function listaJogos(){
		$jogos = file_get_contents("json/jogos.json");
		$arrayJogos = json_decode($jogos,TRUE);
		return $arrayJogos;
	}