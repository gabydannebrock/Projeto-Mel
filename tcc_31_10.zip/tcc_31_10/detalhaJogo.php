<?php
  include "cabecalho.php";
  include "listaJogos.php";
  $arrayJogos = listaJogos();
  if (isset($_GET['id'])) {
    $idJogo = $_GET['id'];
    foreach ($arrayJogos as $jogo) {
      if ($jogo['id']==$idJogo) {
        $jogo_encontrado = $jogo;
      }
    }
  }
  
?>
<h1 class="jogos"><?=$jogo_encontrado['titulo'] ?></h1>
<img class="imagem" src="fotos/<?= $jogo_encontrado['foto']?>">
<section id="jogos">
  <h1 class="text3"><?=$jogo_encontrado['resenha'] ?></h1>

  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ <?=$jogo_encontrado['autor'] ?>
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ<?= $jogo_encontrado['notaAutor'] ?>
    </a>
    <?php

    if(isset($_GET['cont'])){

      if($_GET['cont']==0 ) {


        echo"
        <a href='detalhaJogo.php?cont=1&id=$idJogo'>

        <div class='ui labeled button' tabindex='0'>
        <div class='ui red button'>
        <i class='thumbs up outline icon'></i> Like


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ";

      }else{
        echo"
        <a href='detalhaJogo.php?cont=0&id=$idJogo'>

        <div class='ui labeled button' tabindex='0'>
        <div class='ui blue button'>
        <i class='thumbs down outline icon'></i> Dislike


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ";
      }
    }else{
      $_GET['cont']=0;
    }

    ?>
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>

  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

  <?php
  include"rodape.php";
  ?>