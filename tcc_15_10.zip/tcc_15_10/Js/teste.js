$(document).ready(function(){

	$('.ui.rating')
  .rating()
;
})