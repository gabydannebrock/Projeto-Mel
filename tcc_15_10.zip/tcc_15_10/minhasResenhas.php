<?php
include'cabecalho.php';
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
  position: relative;
  width: 50%;
  float: left;
}

.image {
  display: block;
  width: 80%;
  height: 100%;
  float: center;
}

.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: .5s ease;
  background-color: #008CBA;
  float: center;
}

.container:hover .overlay {
  opacity: 1;
}

.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}
</style>

</head>


<h1 class="ui horizontal divider header" id="tamCadastro">Minhas Resenhas</h1>

<section class="separar1"></section>

<center>
 <div class="two wide column">

  <div class="container">
    <a href="lol.php">
      <div class="sides">
        <div class="active side">
          
          <img src="fotos/lol.jpg" alt="Avatar" class="image">
          <div class="overlay">
            <div class="text">League Of Legends</div>
          </div>
          
        </div>
      </div>
    </a>
  </div>

  <div class="container">
    <a href="dota.php">
      <div class="ui people shape fotos">
        <div class="sides">
          <div class="active side">
            <img src="fotos/dota1.jpg" alt="Avatar" class="image">
            <div class="overlay">
              <div class="text">Dota 2</div>
            </div>
          </div>
        </div>
      </div>
    </a>
  </div>
</center>

<section class="separar">ㅤ</section>

<section class="minhasResenhas"> <br>
  <div class="colunabaixo">
    <section class="exclu">
      <a href="excluir.php">
        <button class="ui instagram button">ㅤㅤㅤExcluirㅤㅤㅤ</button>
      </a>

      <a href="alterarResenha.php">
        <button class="ui instagram button">ㅤㅤㅤAlterarㅤㅤㅤ</button>
      </a>


      <a href="lol.php">
        <button class="ui instagram button">ㅤㅤㅤVisualizarㅤㅤㅤ</button>
      </a> ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ 
    </section>
  </div>
</section>


