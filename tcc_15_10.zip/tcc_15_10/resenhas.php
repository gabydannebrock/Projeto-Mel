
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
	position: relative;
	width: 24%;
	float: left;
}

.image {
	display: block;
	width: 80%;
	height: 100%;
	float: center;
}


.overlay {
	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	height: 100%;
	width: 100%;
	opacity: 0;
	transition: .5s ease;
	background-color: #008CBA;
	float: center;
}

.container:hover .overlay {
	opacity: 1;
}

.text {
	color: white;
	font-size: 20px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	text-align: center;
	font-family:cleon;
}
</style>

</head>



<body class="background">


	<div class="ui vertical masthead center aligned segment">


		<br>
		<br>
		<br>
		<center>
			<div class="four wide column">

				<div class="container">
					<a href="lol.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/lol.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">LEAGUE OF LEGENDS</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>


		<center>
			<div class="four wide column">

				<div class="container">
					<a href="dota.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/dota.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">DOTA 2</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="arena.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/arena2.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">ARENA OF VALOR</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="gigantic.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/gigantic.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">GIGANTIC</div>
								</div>
							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<section class="espaco"></section>	
		<br>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="heroes.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/heroes.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">HEROES OF THE STORM</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="paladins.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/paladins.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">PALADINS</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="infinite.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/infinite.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">INFINITE CRISIS</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center> 	

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="strife.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/strife.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">STRIFE</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<section class="espaco"></section>	

		<br>


		<center>
			<div class="four wide column">

				<div class="container">
					<a href="vainglory.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/vainglory.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">VAINGLORY</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>


		<center>
			<div class="four wide column">

				<div class="container">
					<a href="paragon.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/paragon.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">PARAGON</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="pb.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/pb.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">PLAYERUNKNOWN'S BATTLEGROUNDS</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>

		<center>
			<div class="four wide column">

				<div class="container">
					<a href="smite.php?cont=0">
						<div class="sides">
							<div class="active side">

								<img src="fotos/smite.jpg" alt="Avatar" class="image">
								<div class="overlay">
									<div class="text">SMITE</div>
								</div>

							</div>
						</div>
					</a>
				</div>
			</div>
		</center>


	</div>
<br>
<br>
<br
