<?php
include"cabecalho.php";
?>
<h1 class="jogos">Arena Of Valor</h1>
<img class="imagem" src="fotos/arena2.jpg">

<section id="jogos">
	<h1 class="text3">Arena of Valor, o MOBA extremamente competitivo da Tencent Games, está disponível de forma gratuita para dispositivos iOS e Android no Brasil. Arena of Valor conta com partidas de 10 a 15 minutos recheadas de ação frenética em grupos de 5×5 jogadores, apresentando uma lista de campeões épicos, cada um com estilo de jogo e habilidades únicas. Como um dos primeiros jogos lançados pela Tencent na América Latina, o aguardado game traz uma visão acessível e com design primoroso do estilo estratégico de jogabilidade MOBA. O jogo está disponível em Português do Brasil e Espanhol da América Latina. Com mais de 200 milhões de usuários na China, Honor of Kings foi o jogo mobile da Tencent que transformou o MOBA em um fenômeno cultural. Agora, três quartos da geração mais jovem de chineses jogam Arena of Valor, e sua paixão por sua comunidade é incomparável a qualquer outro jogo do gênero. A Tencent está trazendo a emoção e o apelo dos jogos MOBA AAA para os jogadores do Brasil e da América Latina com Arena of Valor.</h1>

	<section>
		<a class="ui label">	
			<strong> ㅤAutor:</strong> soster
		</a>

		<a class="ui label">
			<strong>ㅤ Nota do Autor:</strong>ㅤ8,6
		</a>

   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="arena.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';

    }else{
      echo '
      <a href="arena.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>

      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>
  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
  <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>

<?php
include"rodape.php";
?>
