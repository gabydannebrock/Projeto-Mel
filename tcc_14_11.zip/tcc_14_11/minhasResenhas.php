<?php
include"cabecalho.php";
?>

<link rel="stylesheet" type="text/css" href="../Semantic/semantic.css">
<link rel="stylesheet " type="text/css" href="./css.css"> 
<link rel="shortcut icon" type="image/x-icon" href="../fotos/favicon.ico">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


<style>
body{
 color: white;
}
h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif,
}
</style>



<div class="w3-content" style="max-width:1400px">
  <br>
  <center>
    <header class="w3-container w3-center w3-padding-32"> 
      <h1 class=" horizontal divider header"><b>MINHAS RESENHAS</b></h1>
    </header>
  </center>


  <div class="w3-row">

    <div class="w3-col l8 s12">

      <div class="w3-card-4 w3-margin w3-white">
        <a href="heroes.php"><img src="fotos/heroes2.jpg" alt="Nature" style="width:100%"></a>
        <div class="w3-container">
          <h3><b>HEROES OF THE STORM</b></h3>
          <h5><span class="w3-opacity">Junho 16, 2018</span></h5>
        </div>

        <div class="w3-container">
          <p>Lançado em 2015, o caçula dos melhores jogos MOBA foi lançado pela Blizzard. Ele surgiu tentando mudar um pouco o conceito fechado dos MOBAs, que sempre seguem uma orientação tradicional dos mapas e dos personagens. Em HotS existem 10 mapas diferentes para travar as batalhas, e cada mapa tem objetivos e mecânicas diferentes. Uma boa ideia da Blizzard foi colocar como heróis do jogo os personagens já consagrados, vindos de outras franquias da desenvolvedora.</p>
          <div class="w3-row">
            <div class="w3-col m8 s12">
              <a href="alterarResenha.php"><p><button class="w3-button w3-white botao"><b>EDITAR »</b></button></p></a>
              <a href="excluir.php"><p><button class="w3-button w3-white botao"><b>EXCLUIR »</b></button></p></a>
            </div>
            <div class="w3-col m4 w3-hide-small">
              <p><span class="w3-padding-large w3-right"><b>Comments </b> <span class="w3-badge">2</span></span></p>
            </div>
          </div>
        </div>
      </div><hr> 
      <div class="w3-card-4 w3-margin w3-white">
        <a href="gigantic.php"><img src="fotos/gigantic2.jpg" alt="Norway" style="width:100%"></a>
        <div class="w3-container">
          <h3><b>GIGANTIC</b></h3>
          <h5><span class="w3-opacity">Maio 15, 2018</span></h5>
        </div>

        <div class="w3-container">
          <p>Gigantic traz a proposta de um MOBA onde o alvo primordial a ser atacado é um colossal monstro chamado de Guardião, que não fica parado, e sim revida atacando com toda sua força. Sozinho, nenhum jogador é capaz de pará-lo. Para isso, hà um time de cinco jogadores que deverão proteger seu guardião e derrotar o guardião inimigo em uma batalha titânica. As opções de personagens são limitadas se comparadas com outros MOBAs.</p>
          <div class="w3-row">
            <div class="w3-col m8 s12">
              <a href="alterarResenha.php"><p><button class="w3-button w3-white botao"><b>EDITAR »</b></button></p></a>
              <a href="excluir.php"><p><button class="w3-button w3-white botao"><b>EXCLUIR »</b></button></p></a>
            </div>
            <div class="w3-col m4 w3-hide-small">
              <p><span class="w3-padding-large w3-right"><b>Comments  </b> <span class="w3-badge">1</span></span></p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="w3-col l4">
      <div class="w3-card w3-margin w3-margin-top">
        <a href="lol.php"><img src="fotos/lol.jpg" style="width:100%"></a>
        <div class="w3-container w3-white">
          <h4><b>League Of Legends</b></h4>
          <p>LoL (League of Legends) é um jogo online competitivo que mistura a velocidade e a intensidade de um RTS com elementos de RPG.</p>
          <div class="w3-row">
            <div class="w3-col m8 s12">
              <a href="alterarResenha.php"><p><button class="w3-button w3-white botao"><b>EDITAR »</b></button></p></a>
              <a href="excluir.php"><p><button class="w3-button w3-white botao"><b>EXCLUIR »</b></button></p></a>
            </div>
            <div class="w3-col m4 w3-hide-small">
              <p><span class="w3-padding-large w3-right"><b>Comments  </b> <span class="w3-badge">3</span></span></p>
            </div>
          </div>
        </div>
      </div><hr>

      <div class="w3-card w3-margin">
        <div class="w3-container w3-padding">
          <h4>Outras Resenhas</h4>
        </div>
        <a href="#">
        <ul class="w3-ul w3-hoverable w3-white">
          <li class="w3-padding-16">
            <img src="fotos/dota1.jpg" alt="Image" class="w3-left w3-margin-right" style="width:100px">
            <span class="w3-large">Dota 2</span>
            <hr>
          </li>
        </a>

        <a href="#">
        <li class="w3-padding-16">
          <img src="fotos/pb2.jpg" alt="Image" class="w3-left w3-margin-right" style="width:100px">
          <span class="w3-large">PUBG</span>
          <hr>
        </li>
      </a>

        <a href="#">
        <li class="w3-padding-16 w3-hide-medium w3-hide-small">
          <img src="fotos/paragons2.jpg" alt="Image" class="w3-left w3-margin-right" style="width:100px">
          <span class="w3-large">Paragon</span>
          <hr>
        </li>
        </a>  
      </ul>
    </div>
    <hr> 

  </div>
</div>
</div>
</div>
</div>


<?php
include"rodape.php";
?>