<?php
include"cabecalho.php";
?>
    <h1 class="jogos">Heroes Of The Storm</h1>
    <img class="imagem" src="fotos/heroes2.jpg">
    <section id="jogos">
      <h1 class="text3">Lançado em 2015, o caçula dos melhores jogos MOBA foi lançado pela Blizzard. Ele surgiu tentando mudar um pouco o conceito fechado dos MOBAs, que sempre seguem uma orientação tradicional dos mapas e dos personagens. Em HotS existem 10 mapas diferentes para travar as batalhas, e cada mapa tem objetivos e mecânicas diferentes. Uma boa ideia da Blizzard foi colocar como heróis do jogo os personagens já consagrados, vindos de outras franquias da desenvolvedora. Em HotS é possível jogar com personagens de Diablo, Warcraft, StarCraft e Overwatch. Jogadores iniciantes conseguem aprender rapidamente as funcionalidades do jogo utilizando os tutoriais e os modos de teste para aprender as habilidades dos heróis.</h1>

