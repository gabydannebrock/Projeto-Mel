<?php
include"cabecalho.php";
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
  position: relative;
  width: 74%;
  margin-left: 13%;
  margin-right: 13%;
  margin-bottom: 10%;
}

.image {
  display: block;
  width: 80%;
  height: 100%;
  float: center;
}

.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: .5s ease;
  background-color: #008CBA;
  float: center;
}

.container:hover .overlay {
  opacity: 1;
}

.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}
</style>

</head>

   	<h1 class="ui inverted header" id="minhasResenhas">
   		Minhas Resenhas
  	</h1>

<section class="separar1"></section>

<center>
 <div class="two wide column">

<div class="container">
		<a href="lol.html">
				<div class="sides">
					<div class="active side">
						
						  	<img src="../fotos/lol.jpg" alt="Avatar" class="image">
						  	<div class="overlay">
						   		<div class="text">League Of Legends</div>
						  	</div>
						
					</div>
				</div>
		</a>
</div>

<div class="container">
		<a href="dota.html">
			<div class="ui people shape fotos">
				<div class="sides">
					<div class="active side">
					  	<img src="../fotos/dota1.jpg" alt="Avatar" class="image">
					  	<div class="overlay">
							<div class="text">Dota 2</div>
						  </div>
					</div>
				</div>
			</div>
		</a>
</div>
</center>

<section class="separar">ㅤ</section>

<section class="minhasResenhas"> <br>
	<div class="colunabaixo">
    <section class="exclu">
	    <a href="excluirResenha.html">
	    	<button class="ui instagram button">ㅤㅤㅤExcluirㅤㅤㅤ</button>
	    </a>
    </section>


    <section class="alter">
	    <a href="alterarResenha.html">
	    	<button class="ui instagram button">ㅤㅤㅤAlterarㅤㅤㅤ</button>
	    </a>
    </section>

    <section class="visu">
	    <a href="visualizarResenha.html">
	    	<button class="ui instagram button">ㅤㅤㅤVisualizarㅤㅤㅤ</button>
	    </a>
    </section>
</div>
</section>


