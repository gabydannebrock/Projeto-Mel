<?php
include"cabecalho.php";
?>

<img src="fotos/mario.png">

<h1 class="titulo">
	Moba Arena
</h1>
<h2>Os melhores jogos você encontra aqui!</h2>

<br>
<br>
<a href="#aqui">
	<div  class="ui huge primary button buttonCat">ㅤㅤJogosㅤㅤ<i class="right arrow"></i></div>		
</a>


</div>
</div>

<div id="aqui" class="back">

	<?php
	include"resenhas.php";
	?>