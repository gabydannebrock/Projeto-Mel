<?php
include"cabecalho.php";
?>
    <h1 class="jogos">Dota 2</h1>
    <img class="imagem" src="fotos/dota1.jpg">
    <section id="jogos">
      <h1 class="text3">Dota 2, o famoso MOBA desenvolvido pela Valve e baseado na modificação de warcraft 3, é um jogo em eterna mutação. Seja pela adição de novos heróis, um buff que altera drasticamente o game ou até mesmo eventos especiais, sempre há uma atualização inédita para se explorar. Mesmo com tantas alterações, o game continua tão divertido quanto em seu lançamento. Confira o review completo. A narrativa nunca foi o foco de Dota 2 e até hoje isso permanece verdadeiro. A trama consiste em duas facções (os Iluminados e os Temidos) em eterna guerra para destruir o ancião do time oposto. Até mesmo essa premissa básica não é explorada no jogo, que deixa o gameplay falar por si só. Aqueles que buscam mais informações devem recorrer às descrições de cada personagem, assim como wikis do jogo para entender melhor a história, o que não é ideal.</h1>


