<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	<link rel="stylesheet " type="text/css" href="css/css.css">
	<link rel="stylesheet " type="text/css" href="css.css">	 
	<link rel="shortcut icon" type="image/x-icon" href="fotos/favicon.ico">
	<title></title>
</head>


<body>
	<div class="pusher">

		<div class="ui inverted vertical masthead center aligned segment">

			<div class="ui">
				<div class="ui large secondary inverted pointing menu">
					<a class="toc item">
						<i class="sidebar icon"></i>
					</a>
					<div class="item">
						<img src="fotos/logo.png" class="logo">
					</div>
					<a href="home.php" class=" item" id="item">Home</a>
					<a href="cadResenha.php" class=" item" id="item">Cadastrar Resenha</a>
					<a href="ranking.php" class="item" id="item">Ranking</a>
					<a href="comentario.php" class="item" id="item">Ranking</a>



					
        <div class="right menu">
  		<a href="login.php" class="ui inverted button" id="item1">Login</a>
        </div>
      </div>
    </div>

 