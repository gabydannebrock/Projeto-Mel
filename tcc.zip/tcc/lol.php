<?php
include"cabecalho.php";
?>

<h1 class="jogos">League Of Legends</h1>
<img class="imagem" src="fotos/lol1.jpg">
<section id="jogos">
  <h1 class="text3">LoL (League of Legends) é um jogo online competitivo que mistura a velocidade e a intensidade de um RTS com elementos de RPG. Duas equipes de poderosos campeões, cada um com design e estilo único, lutam em diversos campos de batalha e modos de jogo. Com um elenco de campeões em constante expansão, atualizações frequentes e uma cena competitiva exuberante, LoL oferece diversão incessante para jogadores de todos os níveis de habilidade.
  O LoL conta com 118 personagens, cada um com seus próprios estilos, habilidades e histórias, cada um desses com suas particularidades, desde o modo de andar até em sua fala. Eles são divididos em 5 classes dentro do jogo. Assassino, Lutador, Mago, Suporte, Tanque e Francoatirador. Porém, os jogadores criaram outras classes para agilizar a escolha de um bom time dentro do jogo, que são eles ADC, Top, Mid, Suporte e Jungle.</h1>

