<?php
include"cabecalho.php";
?>




        <section class="margem">
           <h1 class="cadResenha">Alteração Resenha</h1>
      <form class="ui form">

        <div class="field">
          <h1 class=" fiel text cadResenha1">Motivo da Denuncia</h1>
          <div class="two fields">

            <div class="field nome cadBotao">
              <input type="text" name="shipping[last-name]" placeholder="Denunciar">
            </div>
          </div>
        </div>

            <br>
      <div class="ui button " tabindex="0">Enviar Denuncia</div>
      </div>
    </div>



  </section>


    <div class="ui vertical footer segment">
    <div class="ui center aligned container">
      <div class="ui stackable inverted divided grid">
        <div class="three wide column centered">
        </div>
      </div>

      <div class="seven wide column">
        <br>
        <br>
        <a href="https://pt-br.facebook.com/">
          <button class="blue ui facebook button">
            <i class="facebook icon"></i>
            Facebook
          </button>
        </a>
        <a href="https://twitter.com/login?lang=pt">
          <button class="blue ui twitter button">
            <i class="twitter icon"></i>
            Twitter
          </button>
        </a>
        <a href="https://www.instagram.com/?hl=pt-br">
          <button class=" blue ui instagram button">
            <i class="instagram icon"></i>
            Instagram
          </button>
        </a>
        <br>
        <div class="ui horizontal inverted small divided link list">
          <a class="item" href="#">Mapa do Site</a>
          <a class="item" href="#">Contato</a>
          <a class="item" href="#">Termos e Condiçoes</a>
          <a class="item" href="#">Politica de Privacidade</a>
        </div>
      </div>
    </div>
  </body>
  </html>