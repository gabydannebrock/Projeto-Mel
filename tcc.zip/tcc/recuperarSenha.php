<?php
include"cabecalho.php";
?>

<section class="espaco"></section>

  <div class="ui vertical footer segment">
    <div class="ui center aligned container">
      <div class="ui stackable inverted divided grid">
        <div class="three wide column centered">
        </div>
      </div>

      <div class="seven wide column">
        <br>
        <br>
        <a href="https://pt-br.facebook.com/">
          <button class="blue ui facebook button">
            <i class="facebook icon"></i>
            Facebook
          </button>
        </a>
        <a href="https://twitter.com/login?lang=pt">
          <button class="blue ui twitter button">
            <i class="twitter icon"></i>
            Twitter
          </button>
        </a>
        <a href="https://www.instagram.com/?hl=pt-br">
          <button class=" blue ui instagram button">
            <i class="instagram icon"></i>
            Instagram
          </button>
        </a>
        <br>
        <div class="ui horizontal inverted small divided link list">
          <a class="item" href="#">Mapa do Site</a>
          <a class="item" href="#">Contato</a>
          <a class="item" href="#">Termos e Condiçoes</a>
          <a class="item" href="#">Politica de Privacidade</a>
        </div>
      </div>
    </div>
  </body>
  </html>