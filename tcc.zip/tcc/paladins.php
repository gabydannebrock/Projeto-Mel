<?php
include"cabecalho.php";
?>


<h1 class="jogos">Paladins</h1>
<img class="imagem" src="fotos/paladins2.jpg">
<section id="jogos">
  <h1 class="text3">Paladins é um shotter em primeira pessoa desenvolvido pelos estúdios Hi-Rez, O jogo usa uma temática fantástica no qual os campeões com que jogamos são paladinos defensores do reino. O jogo é gratis para jogar, toda semana temos alguns campeões abertos para jogar, e com o dinheiro que conseguimos ao vencer partidas podemos habilitar campeões permanentemente para usá-los a qualquer tempo. Os campeões são divididos em 4 tipos: Dano, Flanco, Suporte e Tanquer. O jogo é gratuito para jogar e por isso precisa ganhar dinheiro de alguma forma, no jogo é possível comprar cristais com dinheiro real, e utilizando eles conseguimos comprar campeões e vários itens cosméticos.</h1>

