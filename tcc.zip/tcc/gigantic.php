<?php
include"cabecalho.php";
?>

<h1 class="jogos">Gigantic</h1>
<img class="imagem" src="fotos/gigantic2.jpg">
<section id="jogos">
  <h1 class="text3">Gigantic traz a proposta de um MOBA onde o alvo primordial a ser atacado é um colossal monstro chamado de Guardião, mas ele não ficará parado, irá revidar atacado com toda sua força e sozinho nenhum jogador é capaz de pará-lo. Para isso haverá um time de cinco jogadores que deverão proteger seu guardião e derrotar o guardião inimigo em uma batalha titânica. As opções de personagens são limitadas se comparadas com outros MOBAs, mas cada uma delas possuem grandes diferenças entre si, não tendo assim personagens com ataques semelhantes. Dentre eles há personagens de ataques rápidos, furtivos, portadores de armas de fogo, tankers, magos, atiradores de longo alcance e personagens de ataque físicos de curto alcance. Os Guardiões também são diferentes e possuem modos de ataques, pontos fracos e habilidades diferentes. Eles irão interagir e ajudar na batalha, esmagando adversários em seu caminho. O jogador deve procurar o ponto fraco no guardião inimigo e atacá-lo para vencer a equipe.</h1>

