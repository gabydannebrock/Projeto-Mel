<?php
include"cabecalho.php";
?>


    <h1 class="jogos">Vainglory</h1>
    <img class="imagem" src="fotos/vainglory.jpg">
    <section id="jogos">
      <h1 class="text3">O Vainglory é um jogo multiplayer de arena de batalha online (MOBA) semelhante aos populares MOBAs, como League of Legends e Dota 2, mas projetado para smartphones e tablets, o jogo é uma versão do gênero MOBA em que duas equipes opostas de três ou cinco jogadores lutam para destruir a base inimiga, controlando o caminho entre as bases, que é alinhada por torres e guardada por criaturas inimigas controladas por IA. Fora do caminho, os jogadores lutam pelos pontos de controle que fornecem recursos.Em Vainglory , as equipes têm cinco jogadores, cada um controlando um avatar , conhecido como "herói", de seu próprio dispositivo. Personagens mais fracos controlados por computador , chamados "minions", aparecem nas bases da equipe e seguem as pistas para a base do time adversário, lutando contra inimigos e torres no caminho. O revestimento das pistas são torres de torre que repelem o fluxo de lacaios e heróis inimigos. O objetivo do jogador é destruir as torres inimigas e, finalmente, o "cristal Vão" na base do time inimigo.</h1>

