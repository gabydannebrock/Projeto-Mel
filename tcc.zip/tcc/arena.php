<?php
include"cabecalho.php";
?>
<h1 class="jogos">Arena Of Valor</h1>
<img class="imagem" src="fotos/arena2.jpg">
<section id="jogos">
 <h1 class="text3">Arena of Valor, o MOBA extremamente competitivo da Tencent Games, está disponível de forma gratuita para dispositivos iOS e Android no Brasil. Arena of Valor conta com partidas de 10 a 15 minutos recheadas de ação frenética em grupos de 5×5 jogadores, apresentando uma lista de campeões épicos, cada um com estilo de jogo e habilidades únicas. Como um dos primeiros jogos lançados pela Tencent na América Latina, o aguardado game traz uma visão acessível e com design primoroso do estilo estratégico de jogabilidade MOBA. O jogo está disponível em Português do Brasil e Espanhol da América Latina. Com mais de 200 milhões de usuários na China, Honor of Kings foi o jogo mobile da Tencent que transformou o MOBA em um fenômeno cultural. Agora, três quartos da geração mais jovem de chineses jogam Arena of Valor, e sua paixão por sua comunidade é incomparável a qualquer outro jogo do gênero. A Tencent está trazendo a emoção e o apelo dos jogos MOBA AAA para os jogadores do Brasil e da América Latina com Arena of Valor.</h1>

   <h4 class="autor">Autor: Dimitri Miranda</h4>

