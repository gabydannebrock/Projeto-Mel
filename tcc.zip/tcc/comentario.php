<?php
include"cabecalho.php";
?>



   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>





<div class="ui comments">
  <h3 class=" comentario">Comentário</h3>
  <div class="comment">
    <a class="avatar">
      <img src="fotos/usuario4.png">
    </a>
    <div class="content">
      <a class="author ">Gabrielle</a>
      <div class="metadata">
        <span class="date ">Hoje às 5:42PM</span>
      </div>
      <div class="text">Adorei essa resenha!</div>
      <div class="actions">
        <a class="reply">Reply</a>
        <a class="reply">Editar</a>
        <a class="reply">Excluir</a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="fotos/usuario2.png">
    </a>
    <div class="content">
      <a class="author">Elliot Fu</a>
      <div class="metadata">
        <span class="date">Ontem às 13:30AM</span>
      </div>
      <div class="text">
        <p>Isto foi muito útil para a minha pesquisa. Muito obrigado!</p>
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <img src="fotos/usuario1.jpg">
        </a>
        <div class="content">
          <a class="author">Jenny Hess</a>
          <div class="metadata">
            <span class="date">Agora</span>
          </div>
          <div class="text">Elliot você está sempre tão certo :) </div>
          <div class="actions">
            <a class="reply">Reply</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="fotos/usuario3.png">
    </a>
    <div class="content">
      <a class="author">Joe Henderson</a>
      <div class="metadata">
        <span class="date">5 dias atrás</span>
      </div>
      <div class="text">Cara, isso foi impressionante. Muito obrigado </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea></textarea>
    </div>
    <div class="ui blue labeled submit icon button"><i class="icon edit"></i> Responder </div>
  </form>
</div>