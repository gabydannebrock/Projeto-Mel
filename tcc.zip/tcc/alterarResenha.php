<?php
include"cabecalho.php";
?>


        <section class="margem">
      <h1 class="cadResenha">Alteração Resenha</h1>
      <form class="ui form">

        <div class="field">
          <h1 class=" fiel text cadResenha1">Título</h1>
          <div class="two fields">

            <div class="field nome cadBotao">
              <input type="text" name="shipping[last-name]" placeholder="Título">
            </div>
          </div>
        </div>


        <div class="field">
          <h1 class=" fiel text cadResenha1">Nota do Autor</h1>
          <div class="two fields">

            <div class="field nome">
              <input class="cadBotao" type="text" name="shipping[last-name]" placeholder="Nota">
            </div>
          </div>
        </div>

        <div class="field">
          <h1 class=" fiel text cadResenha1">Resenha</h1>
          <div class="two fields">


            <div class="field nome">
              <input type="text" name="shipping[last-name]" placeholder="Resenha">
            </div>
          </div>
        </div>

        <div class="field">
          <h1 class=" fiel text cadResenha1">Enviar Foto</h1>
          <div class="two fields">

            <div class="field nome ">
              <input type="file" name="arquivo" placeholder="Escolher Arquivo">
            </div>
          </div>
        </div>

        <br>
      <div class="ui button" tabindex="0">Enviar Alteração</div>
      </div>
    </div>

  </section>
