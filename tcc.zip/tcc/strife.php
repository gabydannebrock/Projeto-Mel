<?php
include"cabecalho.php";
?>

<h1 class="jogos">Strife</h1>
<img class="imagem" src="fotos/strife2.jpg">
<section id="jogos">
  <h1 class="text3">Strife é um MOBA com ação 3D, com um elenco colorido de personagens e gráficos de cartoony brilhantes. O jogo possui um sistema de crafting exclusivo e vários outros recursos originais que o diferenciam de outros MOBAs.
  As características mais proeminentes do jogo incluem seu sistema de animais de estimação e crafting. Além de simplesmente selecionar um herói, os jogadores também podem escolher entre mais de uma dúzia de animais de estimação para acompanhá-los na batalha. Cada animal tem 3 habilidades distintas que melhoram o herói do jogador. Qualquer animal de estimação pode ser acompanhado de qualquer campeão. O sistema de criação de itens do jogo permite aos jogadores personalizar os itens disponíveis na loja com as estatísticas que eles desejam.</h1>
  